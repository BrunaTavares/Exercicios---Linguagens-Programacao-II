<?php
//Verifica a formatacao
function validar($valor) 
{
	$proibido = array("'",'\\','<','>',"\"");
	$valor = str_replace($proibido, "", $valor);
	return $valor;
}

function formatar($data)
{
	return strtotime(substr($data, 6, 4)."-".substr($data, 3, 2)."-".substr($data, 0, 2)." " .substr($data, 10, 6)) * 1000;
}
 ?>
