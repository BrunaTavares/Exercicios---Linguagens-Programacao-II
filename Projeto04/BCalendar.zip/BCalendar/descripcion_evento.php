<?php

//incluimos nuestro archivo config
    include 'config.php'; 

    // Incluimos nuestro archivo de funciones
    include 'funcoes.php';

    // Obtenemos el id del evento
    $id  = validar($_GET['id']);

    // y lo buscamos en la base de dato
    $bd  = $conexao->query("SELECT * FROM eventos WHERE id=$id");

    // Obtenemos los datos
    $row = $bd->fetch_assoc();

    // titulo 
    $titulo=$row['title'];

    // cuerpo
    $evento=$row['body'];

    // Fecha inicio
    $inicio=$row['inicio_normal'];

    // Fecha Termino
    $final=$row['final_normal'];

// Eliminar evento
if (isset($_POST['eliminar_evento'])) 
{
    $id  = validar($_GET['id']);
    $sql = "DELETE FROM eventos WHERE id = $id";
    if ($conexao->query($sql)) 
    {
        echo "Evento excluído";
    }
    else
    {
        echo "O Evento não pode ser excluído";
    }
}
 ?>

<!DOCTYPE html>
<html lang="pt_BR">
<head>
	<meta charset="UTF-8">
	<title><?=$titulo?></title>
</head>
<body>
	 <h3><?=$titulo?></h3>
	 <hr>
     <b>Data de início:</b> <?=$inicio?>
     <b>Data de fim:</b> <?=$final?>
 	<p><?=$evento?></p>
</body>
<form action="" method="post">
    <button type="submit" class="btn btn-danger" name="eliminar_evento">Excluir</button>
</form>
</html>
