<?php

// Dados de conexão
$servidor='localhost:3307';
$usuario='root';
$pass='';
$bd='eventos';

$conexao = new mysqli($servidor, $usuario, $pass, $bd);	
$conexao->set_charset('utf8');

if ($conexao->connect_errno) {
	echo "Erro ao conectar ao BD {$conexao->connect_errno}";
}

// Url donde estara el proyecto, debe terminar con un "/" al final
$base_url=$_SERVER['REQUEST_URI'];

?>
