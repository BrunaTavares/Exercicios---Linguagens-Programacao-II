// config/database.js
module.exports = {
    'connection': {
        'host': 'localhost',
        'user': 'root',
        'password': 'brunaworkbench'
    },
	'database': 'social',
    'users_table': 'users'
};